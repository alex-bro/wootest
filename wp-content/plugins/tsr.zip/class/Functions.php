<?php
namespace tsr;

if (!defined('ABSPATH')) exit;

class Functions
{
    /**
     * construct method
     */
    function __construct()
    {

    }

    /**
     * get current dmt time
     */
    static function get_time_gmt()
    {
        return time() + (get_option('gmt_offset') * 60 * 60);
    }

    /**
     * get uri by url from server side
     */
    static function get_clear_uri($url){
        $str = str_ireplace(site_url(),'',$url);
        if(substr($str,0,1) == '/'){
            $str = substr($str,1);
        }
        if(substr($str,strlen($str)-1,1) == '/'){
            $str = substr($str,0,-1);
        }
        return $str;
    }
}