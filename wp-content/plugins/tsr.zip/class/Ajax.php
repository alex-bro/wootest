<?php
namespace tsr;

if (!defined('ABSPATH')) exit;

class Ajax
{
    /**
     * construct method
     */
    function __construct()
    {
        add_action('init', [$this, 'ajax_init']);
    }

    /**
     * init ajax actions
     */
    function ajax_init()
    {
        add_action('wp_ajax_nopriv_ajax_get_note', [$this, 'get_note']);
        add_action('wp_ajax_ajax_get_note', [$this, 'get_note']);
    }

    /**
     * get uids from client and put response to client
     */
    function get_note()
    {
        check_ajax_referer('ajax-tr-nonce', 'security');
        $data = $_POST['data'];

        echo json_encode([]);
        wp_die();
    }


}