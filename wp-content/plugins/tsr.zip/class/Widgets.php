<?php
namespace tsr;

if (!defined('ABSPATH')) exit;

class Widgets

{
    /**
     * construct method
     */
    function __construct()
    {

    }
}