<?php
namespace tsr;

if (!defined('ABSPATH')) exit;

class Db
{
    static public $table;

    /**
     * construct method
     */
    function __construct()
    {
        global $wpdb;
        self::$table = $wpdb->get_blog_prefix() . 'abv_tsr';

    }


}