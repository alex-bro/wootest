<?php
namespace tsr;

if (!defined('ABSPATH')) exit;

class Core
{
    static public $plugin_dir, $plugin_url, $is_this_plugin = false;

    /**
     * construct method
     */
    function __construct()
    {
        self::$plugin_dir = str_replace('class/', '', plugin_dir_path(__FILE__));
        self::$plugin_url = plugins_url('tsr');

        add_action('admin_enqueue_scripts', [$this, 'is_this_plugin'],1);
        add_action('init', [$this, 'add_scripts']);
        add_action('admin_enqueue_scripts', [$this, 'add_admin_scripts']);
        add_action('wp_footer', [$this, 'show_footer']);
    }

    /**
     * check the plugin part in admin site part
     */
    function is_this_plugin(){
        if(
            (isset($_REQUEST)) && (isset($_REQUEST['page']) ) &&
            (
                1 || //mock
                ($_REQUEST['page'] == 'abv_viravi') ||
                ($_REQUEST['page'] == 'abv_va_manage') ||
                ($_REQUEST['page'] == 'abv_va_settings') ||
                ($_REQUEST['page'] == 'abv_va_yt_search')
            )
        ){
            self::$is_this_plugin = true;
        }
    }

    /**
     * plugin localise
     */
    function localise(){
        load_plugin_textdomain( 'tsr', false, self::$plugin_dir . '/languages/' );
    }

    /**
     * plug scripts to front pages
     */
    function add_scripts()
    {


    }

    /**
     * plug scripts to admin pages
     */
    function add_admin_scripts()
    {


    }

    /**
     * add nonce field to front pages
     */
    function show_footer()
    {
        wp_nonce_field('ajax-tr-nonce', 'security_tr');
    }
}