<?php
/**
 * Plugin Name: Tsr
 * Author: IVCOR
 * Version: 1
 */

include 'abv_autoload.php';

register_activation_hook(__FILE__, 'abv_tr_plugin_activate');
register_deactivation_hook(__FILE__, 'abv_tr_plugin_deactivate');
add_action('admin_init', 'abv_tr_load_plugin');

function abv_tr_plugin_activate()
{
    add_option('Activated_Plugin_Tsr', 1);
}

function abv_tr_load_plugin()
{
    if (is_admin() && get_option('Activated_Plugin_Linxact') == 1) {
        delete_option('Activated_Plugin_Linxact');


    }
}

function abv_tr_plugin_deactivate()
{

}

global $abv_tsr;
$abv_tsr = new \tsr\Core();